//
//  ViewController.swift
//  SmartAppDev_A2_AttemptThree
//
//  Created by Richard Kalnarajs (Student) on 19/04/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

