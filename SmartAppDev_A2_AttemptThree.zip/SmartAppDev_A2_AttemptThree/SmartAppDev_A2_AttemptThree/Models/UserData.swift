//Creates Static user class to be used across the whole app
class UserData
{
    static let shared = UserData()
    var currentUser: User? = nil
}
