//Declare Properties of Task struct
import Foundation

struct Task: Codable, Identifiable {
    let id: Int
    let name: String
    let description: String
    let due_date: String
    let project_id: Int
    var status: String

}

