import UIKit

class SelectProjectController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate
{
    var passableDate: Int?
    var projectTitle: String?
    
    var projectId: Int?

    @IBOutlet weak var dropdown: UIPickerView!
    struct Item: Codable {
        let id: Int
        let name: String
    }
    
    var items: [Item] = []
    var selectedItemId: Int?
    
    //allows the passthrough of data between the two view controllers
    //Sends ProjectID and ProjectTItle
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "detailsSegue"{
            let DetailsVC = segue.destination as! ProjectDetailsController
            DetailsVC.projectId = self.selectedItemId
            DetailsVC.projectTitle = self.projectTitle
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Select the first item in the picker view by default
        if let firstItem = items.first {
            selectedItemId = firstItem.id
            projectTitle = firstItem.name
            dropdown.selectRow(0, inComponent: 0, animated: false)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Get project information based on userID
        let userId = UserData.shared.currentUser!.id
        let url = URL(string: "http://127.0.0.1:5000/api/projects/get/titles?id=\(userId)")!
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else { return }
            do {
                //Decode JSON
                self.items = try JSONDecoder().decode([Item].self, from: data)
                
                DispatchQueue.main.async {
                    self.dropdown.reloadAllComponents()
                }
            } catch {
                print("error decoding JSON")
            }
        } .resume()
        
        dropdown.dataSource = self
        dropdown.delegate = self
    }
        
    //Functions for project picker
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return items.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return items[row].name
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if row < items.count {
            let selectedItem = items[row]
            selectedItemId = selectedItem.id
            projectTitle = selectedItem.name
            
        } else {
            selectedItemId = nil
        }
    }
}
