import UIKit

class ManageProjectController: UIViewController
{
    @IBOutlet weak var textView: UITextView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let userId = UserData.shared.currentUser!.id
        
        let url = URL(string: "http://localhost:5000/api/projects/get/byuserid?id=\(userId)")
        //let url = URL(string: "http://127.0.0.1:5000/api/projects/get/all")!
        
        //Empty array of projets
        var projects: [Project] = []
        
        URLSession.shared.fetchData(for: url!)
        {
            (result: Result<[Project], Error>) in switch result
            {
                case .success(let results): projects.append(contentsOf: results)
                case .failure(let error): print(error)
            }
            
            var projectText = ""
            projects.forEach
            {
                project in
                projectText += "Project Id: \(project.id)\n"
                projectText += "Project Name: \(project.name)\n"
                projectText += "Description: \(project.description)\n"
                projectText += "Start Date: \(project.start_date)\n"
                projectText += "End Date: \(project.end_date)\n"
            }
            print(projectText)
            
            DispatchQueue.main.async
            {
                self.textView.text = projectText
            }
        }
    }
}

