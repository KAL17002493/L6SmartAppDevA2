import UIKit

class ProjectDetailsController: UIViewController
{
    @IBOutlet weak var textView: UITextView!
    
    var projectId: Int?
    var projectTitle: String?
    
    
    struct Item: Codable {
        let id: Int
        let name: String
    }
    
    var items: [Item] = []
    var selectedItemId: Int?
    
    //allows the passthrough of data between the two view controllers
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "taskSegue"{
            let TaskVC = segue.destination as! TaskViewController
            TaskVC.projectId = self.projectId
        }
    }
    
    
    

    //Display project info
    override func viewDidLoad()
    {
        super.viewDidLoad()
        guard let id = self.projectId else {return}
        let url = URL(string: "http://localhost:5000/api/projects/get/byid?id=\(id)")
        
        //Empty array of projets
        var projects: [Project] = []
        
        URLSession.shared.fetchData(for: url!)
        {
            (result: Result<[Project], Error>) in switch result
            {
                case .success(let results): projects.append(contentsOf: results)
                case .failure(let error): print(error)
            }
            
            //Loop to display project details
            var projectText = ""
            projects.forEach
            {
                project in
                projectText += "Project Id: \(project.id)\n"
                projectText += "Project Name: \(project.name)\n"
                projectText += "Description: \(project.description)\n"
                projectText += "Start Date: \(project.start_date)\n"
                projectText += "End Date: \(project.end_date)\n"
            }
            print(projectText)
            
            //Display Project details
            DispatchQueue.main.async
            {
                self.textView.text = projectText
            }
            print(self.projectId)
        }
    }
    
    //Delete Section
    var delURL: URL?
    @IBAction func deleteProject(_ sender: Any) {
        guard let id = self.projectId else { return }
                let delURL = URL(string: "http://localhost:5000/api/projects/delete/byid?id=\(id)")
                
                var request = URLRequest(url: delURL!)
                request.httpMethod = "DELETE"
                
                URLSession.shared.dataTask(with: request) { (data, response, error) in
                    if let error = error {
                        print(error)
                        return
                    }
                    
                    DispatchQueue.main.async {
                        // Display a message that the project has been deleted
                        self.textView.text = "Project with Id \(id) has been deleted."
                    }
                }.resume()
            }
    
    
    
}
