import UIKit

class TaskViewController: UIViewController
{
    
    @IBOutlet weak var textView: UITextView!
    
    var projectId: Int?
    
    //Pass ProjectID to two connected views
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "newTaskSegue"{
            let NewTaskVC = segue.destination as! NewTaskController
            NewTaskVC.projectId = self.projectId
        }
        if segue.identifier == "taskSelectionSegue"{
            let TaskSelectionVC = segue.destination as! SelectTaskController
            TaskSelectionVC.projectId = self.projectId
            print("Project Id being sent")
            print(self.projectId)
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
print("projectId")
print(projectId)
        
        guard let id = self.projectId else {return}
        print(id)
        //URL
        let url = URL(string: "http://localhost:5000/api/tasks/get/byprojectid?id=\(id)")
        
        //Console Check
        if(url != nil)
        {
            print(id)
            print(url)
        }
        else
        {
            print("Project ID is not being sent from previouse View")
        }
        
        //Empty array of projets
        var tasks: [Task] = []
        
        URLSession.shared.fetchData(for: url!)
        {
            (result: Result<[Task], Error>) in switch result
            {
                case .success(let results): tasks.append(contentsOf: results)
                case .failure(let error): print(error)
            }
            
                var taskText = ""
                tasks.forEach
                {
                    task in
                    taskText += "Task Id: \(task.id)\n"
                    taskText += "Project Id: \(task.project_id)\n"
                    taskText += "Task Name: \(task.name)\n"
                    taskText += "Description: \(task.description)\n"
                    taskText += "Due Date: \(task.due_date)\n"
                    taskText += "Status: \(task.status)\n"
                    taskText += "-------------------\n\n"
                }
                print(taskText)
                
            //Displayed on screen
                DispatchQueue.main.async
                {
                    self.textView.text = taskText
                }
            print(self.projectId)
        }
    }

}
