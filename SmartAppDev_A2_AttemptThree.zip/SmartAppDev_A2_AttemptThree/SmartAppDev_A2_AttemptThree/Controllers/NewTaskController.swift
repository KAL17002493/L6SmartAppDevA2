import UIKit

class NewTaskController: UIViewController
{
    
    @IBOutlet weak var taskDescription: UITextField!
    @IBOutlet weak var taskName: UITextField!
    @IBOutlet weak var notification: UILabel!
    @IBOutlet weak var dueDate: UIDatePicker!
    
    var projectId: Int?
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        print("projectId")
        print(projectId)
        
        
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func createTaskButton(_ sender: Any)
    {
        let status = "In Progress"
        
        guard let id = self.projectId else {return}
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        // Retrieve the selected dates from the date pickers
        let dueDate = dueDate.date
        
        // Format the dates as strings for the parameter dictionary
        let formattedStartDate = dateFormatter.string(from: dueDate)
        
        guard let taskName = taskName.text,
              let taskDescription = taskDescription.text else {
            //Handle the case where either text field is nil
            return
        }
        
        let parameters = ["name": taskName,
                          "description": taskDescription,
                          "due_date": formattedStartDate,
                          "status" : status,
                          "project_id" : id] as [String:Any]
        
        guard let url = URL(string: "http://127.0.0.1:5000/api/tasks/add") else {
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: parameters, options: [])
            request.httpBody = jsonData
        } catch {
            print("Error: \(error.localizedDescription)")
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse,
                  (200..<300).contains(httpResponse.statusCode) else {
                print("Error: Invalid response")
                return
            }
            
            guard let data = data else {
                print("Error: No data received")
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                if let dict = json as? [String: Any],
                   let registerSuccess = dict["Add_Success"] as? Bool,
                   registerSuccess == true {
                    print("Task Creation successful")
                    DispatchQueue.main.async {
                        self.notification.text = "Task creation has been successful"
                        
                    }
                } else {
                    print("Task creation failed")
                }
            } catch {
                print("Error: \(error.localizedDescription)")
            }
        }.resume()
    }
}
