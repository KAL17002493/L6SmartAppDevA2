//
//  EditTaskController.swift
//  SmartAppDev_A2_AttemptThree
//
//  Created by Richard Kalnarajs (Student) on 03/05/2023.
//
import UIKit

class EditTaskController: UIViewController
{
    
    @IBOutlet weak var taskName: UITextField!
    @IBOutlet weak var taskDesc: UITextField!
    @IBOutlet weak var taskDueDate: UIDatePicker!
    
    @IBOutlet weak var taskTitle: UILabel!
    
    @IBOutlet weak var taskStatus: UITextField!

    var taskId : Int?
    var projectId: Int?
    
    let dateFormatter = DateFormatter()
       
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        guard let taskId = self.taskId else {return}
        guard let projectId = self.projectId else {return}
        let url = URL(string: "http://localhost:5000/api/tasks/get/byid?id=\(taskId)")
        
        print("Current task id is \(taskId)")
        
        URLSession.shared.dataTask(with: url!) { data, response, error in
            if let data = data {
                do {
                    let task = try JSONDecoder().decode(Task.self, from: data)
                    DispatchQueue.main.async {
                        print(task)
                        self.taskTitle.text = task.name
                    }
                } catch let error {
                    print(error)
                }
            }
        }.resume()
    }
    
    @IBAction func btnUpdatePressed(_ sender: Any) {
        guard let taskId = self.taskId, let projectId = self.projectId else {
            return
        }
        
        let statusUpdate = "Complete"
        let url = "http://127.0.0.1:5000/api/tasks/get/byid?id=\(taskId)"
        
        URLSession.shared.dataTask(with: URL(string: url)!) { data, response, error in
            guard let data = data else {
                print("Error: no data returned")
                return
            }
            do {
                var task = try JSONDecoder().decode(Task.self, from: data)
                task.status = statusUpdate

                let updateUrl = "http://127.0.0.1:5000/api/tasks/update"
                URLSession.shared.postData(task, urlString: updateUrl) { (result: Result<Task, Error>) in
                    switch result {
                    case .success(let updatedTask):
                        print("Task status updated: \(updatedTask)")
                    case .failure(let error):
                        print("Error updating task status: \(error.localizedDescription)")
                    }
                }
            } catch let error {
                print("Error decoding task: \(error.localizedDescription)")
            }
        }.resume()
    }
    
    
    
    
    
    }
    

